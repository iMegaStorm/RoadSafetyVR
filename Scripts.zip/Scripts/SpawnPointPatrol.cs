using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPointPatrol : MonoBehaviour
{
    public Transform[] waypoints;
    public Transform[] waypoints2;

}
